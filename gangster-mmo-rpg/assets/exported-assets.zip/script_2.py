# Ahora crear los scripts base
player_script = '''extends CharacterBody3D
class_name Player

## Jugador principal del Gangster MMO RPG
## Maneja movimiento 3D, inventario y stats base

@export_group("Movement")
@export var move_speed: float = 5.0
@export var sprint_speed: float = 8.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.003

@export_group("Stats")
@export var max_health: float = 100.0
@export var health: float = 100.0
@export var flow_level: int = 1
@export var street_cred: int = 0

# Referencias a nodos
@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var mesh_instance: MeshInstance3D = $PlayerMesh

# Variables de movimiento
var is_sprinting: bool = false
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

# Variables de items equipados
var equipped_weapon = null
var equipped_clothing: Array = []
var current_flow_bonus: float = 0.0

signal health_changed(new_health: float)
signal flow_changed(new_flow: int)
signal item_equipped(item)

func _ready():
	# Configurar cámara
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	print("🎮 Player spawneado - Level: %d, Street Cred: %d" % [flow_level, street_cred])

func _input(event):
	# Rotación de cámara con mouse
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		if camera_pivot:
			camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity)
			camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, -1.5, 1.5)
	
	# Toggle inventario
	if event.is_action_pressed("inventory"):
		toggle_inventory()
	
	# Sprint
	if event.is_action_pressed("sprint"):
		is_sprinting = true
	elif event.is_action_released("sprint"):
		is_sprinting = false

func _physics_process(delta):
	# Gravedad
	if not is_on_floor():
		velocity.y -= gravity * delta
	
	# Salto
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity
	
	# Movimiento horizontal
	var input_dir = Vector2()
	if Input.is_action_pressed("move_up"):
		input_dir.y -= 1
	if Input.is_action_pressed("move_down"):
		input_dir.y += 1
	if Input.is_action_pressed("move_left"):
		input_dir.x -= 1
	if Input.is_action_pressed("move_right"):
		input_dir.x += 1
	
	if input_dir != Vector2.ZERO:
		input_dir = input_dir.normalized()
		
		# Calcular velocidad con bonificaciones de items
		var current_speed = sprint_speed if is_sprinting else move_speed
		current_speed += get_speed_bonus_from_items()
		
		# Direccion relativa a la rotación del jugador
		var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y))
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, move_speed * 3 * delta)
		velocity.z = move_toward(velocity.z, 0, move_speed * 3 * delta)
	
	move_and_slide()

func get_speed_bonus_from_items() -> float:
	var bonus: float = 0.0
	for clothing in equipped_clothing:
		if clothing and clothing.has_method("get_stat") and clothing.has_stat("movement_speed"):
			bonus += clothing.get_stat("movement_speed") / 100.0 * move_speed
	return bonus

func equip_item(item):
	if not item:
		return false
	
	print("🎽 Equipando: %s (+%d flow)" % [item.item_name, item.flow_bonus])
	equipped_clothing.append(item)
	item_equipped.emit(item)
	update_flow_level()
	return true

func update_flow_level():
	var total_flow = 0
	
	for clothing in equipped_clothing:
		if clothing:
			total_flow += clothing.flow_bonus
	
	current_flow_bonus = total_flow
	flow_changed.emit(flow_level + int(current_flow_bonus / 10))

func take_damage(damage: float, source: String = ""):
	health = max(0, health - damage)
	health_changed.emit(health)
	
	print("💥 Took %d damage from %s (Health: %.0f/%.0f)" % [damage, source, health, max_health])
	
	if health <= 0:
		die()

func die():
	print("💀 Player died - respawning...")
	# TODO: Implementar respawn

func heal(amount: float):
	health = min(max_health, health + amount)
	health_changed.emit(health)

func add_street_cred(amount: int):
	street_cred += amount
	print("📈 Street Cred +%d (Total: %d)" % [amount, street_cred])

func toggle_inventory():
	print("🎒 Toggle inventory (TODO: implementar UI)")

func print_stats():
	print("=== PLAYER STATS ===")
	print("Flow Level: %d (+%.1f from items)" % [flow_level, current_flow_bonus])
	print("Street Cred: %d" % street_cred)
	print("Health: %.0f/%.0f" % [health, max_health])
	print("Clothing items: %d equipped" % equipped_clothing.size())
	print("==================")
'''

# Script base para items
item_script = '''extends Resource
class_name Item

## Clase base para todos los items del juego
## Define propiedades comunes y comportamiento base

enum ItemType {
	WEAPON,
	CLOTHING, 
	ACCESSORY,
	CONSUMABLE
}

enum Rarity {
	COMMON,    # Blanco - Items básicos
	UNCOMMON,  # Verde - Items decentes  
	RARE,      # Azul - Items buenos
	EPIC,      # Morado - Items geniales
	LEGENDARY  # Dorado - Items únicos y divertidos
}

@export var item_name: String = ""
@export var description: String = ""
@export var item_type: ItemType = ItemType.CLOTHING
@export var rarity: Rarity = Rarity.COMMON
@export var icon: Texture2D
@export var mesh: Mesh
@export var flow_bonus: int = 0
@export var price: int = 100

# Stats que pueden tener los items
@export var stats: Dictionary = {}

func get_stat(stat_name: String) -> float:
	return stats.get(stat_name, 0.0)

func has_stat(stat_name: String) -> bool:
	return stat_name in stats

func add_stat(stat_name: String, value: float):
	stats[stat_name] = value

func get_rarity_color() -> Color:
	match rarity:
		Rarity.COMMON:
			return Color.WHITE
		Rarity.UNCOMMON:
			return Color.GREEN
		Rarity.RARE:
			return Color.CYAN
		Rarity.EPIC:
			return Color.MAGENTA
		Rarity.LEGENDARY:
			return Color.GOLD
		_:
			return Color.WHITE

func get_flow_description() -> String:
	if flow_bonus > 0:
		return "+%d Flow ✨" % flow_bonus
	return ""

func get_full_description() -> String:
	var full_desc = description
	
	# Agregar stats
	if stats.size() > 0:
		full_desc += "\\n\\nEffects:"
		for stat in stats:
			var value = stats[stat]
			var sign = "+" if value > 0 else ""
			full_desc += "\\n• %s: %s%.1f%%" % [stat.replace("_", " ").capitalize(), sign, value]
	
	# Agregar flow bonus
	if flow_bonus > 0:
		full_desc += "\\n\\n" + get_flow_description()
	
	return full_desc

func on_equipped(player: Player):
	print("📦 %s equipped!" % item_name)

func on_unequipped(player: Player):
	print("📦 %s unequipped!" % item_name)
'''

# Script para ropa específica
clothing_script = '''extends Item
class_name ClothingItem

## Item de ropa - afecta apariencia y stats del jugador

enum ClothingSlot {
	HEAD,      # Gorras, lentes, máscaras
	CHEST,     # Camisas, buzos, chaquetas  
	LEGS,      # Pantalones, shorts
	FEET,      # Zapatos, zapatillas
	ACCESSORY  # Relojes, cadenas, anillos
}

@export var clothing_slot: ClothingSlot = ClothingSlot.CHEST
@export var material_override: Material

func _init():
	item_type = ItemType.CLOTHING

# Crear items de ejemplo divertidos
static func create_example_items() -> Array[ClothingItem]:
	var items: Array[ClothingItem] = []
	
	# Buzo Adidas Vintage
	var adidas_hoodie = ClothingItem.new()
	adidas_hoodie.item_name = "Buzo Adidas Vintage"
	adidas_hoodie.description = "Un clásico de los 90s. Las tres rayas dan +20% de éxito en robos. Es ciencia, bro."
	adidas_hoodie.clothing_slot = ClothingSlot.CHEST
	adidas_hoodie.flow_bonus = 15
	adidas_hoodie.rarity = Rarity.UNCOMMON
	adidas_hoodie.price = 800
	adidas_hoodie.add_stat("theft_success", 20.0)
	adidas_hoodie.add_stat("street_respect", 10.0)
	items.append(adidas_hoodie)
	
	# Zapatillas Jordan Falsas
	var fake_jordans = ClothingItem.new()
	fake_jordans.item_name = "Air Jordan Retro (Falsas)"
	fake_jordans.description = "Se ven reales hasta que llueve. +15% velocidad porque corres como si te persiguieran."
	fake_jordans.clothing_slot = ClothingSlot.FEET
	fake_jordans.flow_bonus = 12
	fake_jordans.rarity = Rarity.COMMON
	fake_jordans.price = 350
	fake_jordans.add_stat("movement_speed", 15.0)
	fake_jordans.add_stat("escape_chance", 20.0)
	items.append(fake_jordans)
	
	# Cadena de Oro Chunky
	var gold_chain = ClothingItem.new()
	gold_chain.item_name = "Cadena Dorada Chunky"
	gold_chain.description = "Tan chunky que duele el cuello, pero vale la pena por el +25% de intimidación."
	gold_chain.clothing_slot = ClothingSlot.ACCESSORY
	gold_chain.flow_bonus = 20
	gold_chain.rarity = Rarity.RARE
	gold_chain.price = 1500
	gold_chain.add_stat("intimidation", 25.0)
	gold_chain.add_stat("charisma", 15.0)
	items.append(gold_chain)
	
	return items
'''

# Script para el manager de inventario
inventory_manager_script = '''extends Node
class_name InventoryManager

## Maneja el inventario del jugador y los items equipados

signal inventory_updated
signal item_added(item: Item)
signal item_removed(item: Item)
signal item_equipped(item: Item)

@export var max_inventory_slots: int = 20
var inventory_items: Array[Item] = []
var equipped_items: Dictionary = {}

func _ready():
	print("🎒 Inventory Manager initialized - Max slots: %d" % max_inventory_slots)
	
	# Crear algunos items de ejemplo para testing
	add_example_items()

func add_example_items():
	var example_items = ClothingItem.create_example_items()
	for item in example_items:
		add_item(item)
	
	print("✨ Added %d example items to inventory" % example_items.size())

func add_item(item: Item) -> bool:
	if inventory_items.size() >= max_inventory_slots:
		print("❌ Inventory full! Cannot add %s" % item.item_name)
		return false
	
	inventory_items.append(item)
	item_added.emit(item)
	inventory_updated.emit()
	
	print("✅ Added to inventory: %s (Slot %d/%d)" % [item.item_name, inventory_items.size(), max_inventory_slots])
	return true

func remove_item(item: Item) -> bool:
	var index = inventory_items.find(item)
	if index == -1:
		return false
	
	inventory_items.remove_at(index)
	item_removed.emit(item)
	inventory_updated.emit()
	return true

func equip_item(item: Item) -> bool:
	if item not in inventory_items:
		print("❌ Item not in inventory: %s" % item.item_name)
		return false
	
	# Por ahora equipar simplemente y mantener en inventario
	var player = get_tree().get_first_node_in_group("player")
	if player and player.has_method("equip_item"):
		player.equip_item(item)
		item_equipped.emit(item)
		return true
	
	return false

func get_items_by_type(item_type: Item.ItemType) -> Array[Item]:
	var filtered_items: Array[Item] = []
	for item in inventory_items:
		if item.item_type == item_type:
			filtered_items.append(item)
	return filtered_items

func get_inventory_value() -> int:
	var total_value = 0
	for item in inventory_items:
		total_value += item.price
	return total_value

func print_inventory():
	print("=== INVENTORY ===")
	print("Items: %d/%d" % [inventory_items.size(), max_inventory_slots])
	print("Total Value: $%d" % get_inventory_value())
	
	for i in range(inventory_items.size()):
		var item = inventory_items[i]
		var rarity_text = Item.Rarity.keys()[item.rarity]
		print("%d. %s [%s] - $%d (+%d flow)" % [i+1, item.item_name, rarity_text, item.price, item.flow_bonus])
	
	print("=================")
'''

# Script de Game Manager principal
game_manager_script = '''extends Node
class_name GameManager

## Manager principal del juego
## Maneja estados globales, configuración y sistemas principales

signal game_started
signal game_paused
signal game_ended

enum GameState {
	MENU,
	PLAYING,
	PAUSED,
	INVENTORY,
	SETTINGS
}

var current_state: GameState = GameState.MENU
var player: Player = null
var game_time: float = 0.0

@onready var ui_manager: Node = $UIManager
@onready var audio_manager: Node = $AudioManager

func _ready():
	print("🎮 Game Manager initialized")
	configure_for_pixel_art()
	connect_signals()

func _process(delta):
	if current_state == GameState.PLAYING:
		game_time += delta
	
	# Inputs globales
	if Input.is_action_just_pressed("ui_cancel"):
		toggle_pause()

func configure_for_pixel_art():
	# Configurar settings para pixel art 3D
	get_viewport().scaling_3d_mode = Viewport.SCALING_3D_MODE_FSR
	print("🎨 Pixel art settings configured")

func connect_signals():
	# Conectar señales importantes del juego
	pass

func start_game():
	current_state = GameState.PLAYING
	game_started.emit()
	print("🚀 Game started!")

func pause_game():
	current_state = GameState.PAUSED
	get_tree().paused = true
	game_paused.emit()
	print("⏸️ Game paused")

func resume_game():
	current_state = GameState.PLAYING
	get_tree().paused = false
	print("▶️ Game resumed")

func toggle_pause():
	if current_state == GameState.PLAYING:
		pause_game()
	elif current_state == GameState.PAUSED:
		resume_game()

func set_player(new_player: Player):
	player = new_player
	player.add_to_group("player")
	print("👤 Player set: %s" % player.name)

func show_notification(message: String, duration: float = 3.0):
	print("📢 Notification: %s" % message)
	# TODO: Mostrar en UI

func get_formatted_game_time() -> String:
	var minutes = int(game_time) / 60
	var seconds = int(game_time) % 60
	return "%02d:%02d" % [minutes, seconds]
'''

# Crear todos los scripts
scripts = [
    ("scripts/player/Player.gd", player_script),
    ("scripts/items/Item.gd", item_script),
    ("scripts/items/ClothingItem.gd", clothing_script),
    ("scripts/managers/InventoryManager.gd", inventory_manager_script),
    ("scripts/managers/GameManager.gd", game_manager_script)
]

created_count = 0
for script_path, script_content in scripts:
    full_path = os.path.join("gangster-mmo-rpg", script_path)
    
    try:
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        print(f"✅ Script creado: {script_path}")
        created_count += 1
    except Exception as e:
        print(f"❌ Error creando {script_path}: {e}")

print(f"\n🎯 {created_count}/{len(scripts)} scripts creados exitosamente!")
print("\n📋 Scripts base incluidos:")
print("• Player.gd - Controlador del jugador 3D con sistema de items")
print("• Item.gd - Clase base para todos los items del juego")
print("• ClothingItem.gd - Ropa con efectos divertidos (Buzo Adidas, Jordans falsas)")
print("• InventoryManager.gd - Sistema de inventario funcional")
print("• GameManager.gd - Manager principal del juego")