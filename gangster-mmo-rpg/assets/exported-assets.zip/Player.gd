extends CharacterBody3D
class_name Player

## Jugador principal del Gangster MMO RPG
## Maneja movimiento 3D, inventario y stats base

@export_group("Movement")
@export var move_speed: float = 5.0
@export var sprint_speed: float = 8.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.003

@export_group("Stats")
@export var max_health: float = 100.0
@export var health: float = 100.0
@export var flow_level: int = 1
@export var street_cred: int = 0

# Referencias a nodos
@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var mesh_instance: MeshInstance3D = $PlayerMesh

# Variables de movimiento
var is_sprinting: bool = false
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

# Variables de items equipados
var equipped_weapon = null
var equipped_clothing: Array = []
var current_flow_bonus: float = 0.0

signal health_changed(new_health: float)
signal flow_changed(new_flow: int)
signal item_equipped(item)

func _ready():
	# Configurar cámara
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	print("🎮 Player spawneado - Level: %d, Street Cred: %d" % [flow_level, street_cred])

func _input(event):
	# Rotación de cámara con mouse
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		if camera_pivot:
			camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity)
			camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, -1.5, 1.5)

	# Toggle inventario
	if event.is_action_pressed("inventory"):
		toggle_inventory()

	# Sprint
	if event.is_action_pressed("sprint"):
		is_sprinting = true
	elif event.is_action_released("sprint"):
		is_sprinting = false

func _physics_process(delta):
	# Gravedad
	if not is_on_floor():
		velocity.y -= gravity * delta

	# Salto
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	# Movimiento horizontal
	var input_dir = Vector2()
	if Input.is_action_pressed("move_up"):
		input_dir.y -= 1
	if Input.is_action_pressed("move_down"):
		input_dir.y += 1
	if Input.is_action_pressed("move_left"):
		input_dir.x -= 1
	if Input.is_action_pressed("move_right"):
		input_dir.x += 1

	if input_dir != Vector2.ZERO:
		input_dir = input_dir.normalized()

		# Calcular velocidad con bonificaciones de items
		var current_speed = sprint_speed if is_sprinting else move_speed
		current_speed += get_speed_bonus_from_items()

		# Direccion relativa a la rotación del jugador
		var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y))
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, move_speed * 3 * delta)
		velocity.z = move_toward(velocity.z, 0, move_speed * 3 * delta)

	move_and_slide()

func get_speed_bonus_from_items() -> float:
	var bonus: float = 0.0
	for clothing in equipped_clothing:
		if clothing and clothing.has_method("get_stat") and clothing.has_stat("movement_speed"):
			bonus += clothing.get_stat("movement_speed") / 100.0 * move_speed
	return bonus

func equip_item(item):
	if not item:
		return false

	print("🎽 Equipando: %s (+%d flow)" % [item.item_name, item.flow_bonus])
	equipped_clothing.append(item)
	item_equipped.emit(item)
	update_flow_level()
	return true

func update_flow_level():
	var total_flow = 0

	for clothing in equipped_clothing:
		if clothing:
			total_flow += clothing.flow_bonus

	current_flow_bonus = total_flow
	flow_changed.emit(flow_level + int(current_flow_bonus / 10))

func take_damage(damage: float, source: String = ""):
	health = max(0, health - damage)
	health_changed.emit(health)

	print("💥 Took %d damage from %s (Health: %.0f/%.0f)" % [damage, source, health, max_health])

	if health <= 0:
		die()

func die():
	print("💀 Player died - respawning...")
	# TODO: Implementar respawn

func heal(amount: float):
	health = min(max_health, health + amount)
	health_changed.emit(health)

func add_street_cred(amount: int):
	street_cred += amount
	print("📈 Street Cred +%d (Total: %d)" % [amount, street_cred])

func toggle_inventory():
	print("🎒 Toggle inventory (TODO: implementar UI)")

func print_stats():
	print("=== PLAYER STATS ===")
	print("Flow Level: %d (+%.1f from items)" % [flow_level, current_flow_bonus])
	print("Street Cred: %d" % street_cred)
	print("Health: %.0f/%.0f" % [health, max_health])
	print("Clothing items: %d equipped" % equipped_clothing.size())
	print("==================")
