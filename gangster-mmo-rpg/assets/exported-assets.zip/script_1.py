# Verificar y crear la estructura necesaria para los scripts
import os

project_name = "gangster-mmo-rpg"

# Crear las carpetas de scripts específicamente
script_folders = [
    "scripts/player",
    "scripts/items", 
    "scripts/managers",
    "scripts/ui",
    "scripts/networking",
    "scripts/combat",
    "scripts/utilities",
    "scripts/data"
]

# Asegurar que todas las carpetas de scripts existan
for folder in script_folders:
    full_path = os.path.join(project_name, folder)
    os.makedirs(full_path, exist_ok=True)
    print(f"📁 Carpeta asegurada: {folder}")

print("\n✅ Estructura de scripts verificada y creada")