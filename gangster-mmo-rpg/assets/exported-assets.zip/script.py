# Crear el script del jugador principal
player_script = '''extends CharacterBody3D
class_name Player

## Jugador principal del Gangster MMO RPG
## Maneja movimiento 3D, inventario y stats base

@export_group("Movement")
@export var move_speed: float = 5.0
@export var sprint_speed: float = 8.0
@export var jump_velocity: float = 4.5
@export var mouse_sensitivity: float = 0.003

@export_group("Stats")
@export var max_health: float = 100.0
@export var health: float = 100.0
@export var flow_level: int = 1
@export var street_cred: int = 0

# Referencias a nodos
@onready var camera_pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var mesh_instance: MeshInstance3D = $PlayerMesh
@onready var inventory_manager: InventoryManager = $InventoryManager

# Variables de movimiento
var is_sprinting: bool = false
var gravity = ProjectSettings.get_setting("physics/3d/default_gravity")

# Variables de items equipados
var equipped_weapon: WeaponItem = null
var equipped_clothing: Array[ClothingItem] = []
var current_flow_bonus: float = 0.0

signal health_changed(new_health: float)
signal flow_changed(new_flow: int)
signal item_equipped(item: Item)

func _ready():
	# Configurar cámara
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	
	# Conectar señales del inventario
	if inventory_manager:
		inventory_manager.item_equipped.connect(_on_item_equipped)
	
	print("🎮 Player spawneado - Level: %d, Street Cred: %d" % [flow_level, street_cred])

func _input(event):
	# Rotación de cámara con mouse
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		camera_pivot.rotate_x(-event.relative.y * mouse_sensitivity)
		camera_pivot.rotation.x = clamp(camera_pivot.rotation.x, -1.5, 1.5)
	
	# Toggle inventario
	if event.is_action_pressed("inventory"):
		toggle_inventory()
	
	# Sprint
	if event.is_action_pressed("sprint"):
		is_sprinting = true
	elif event.is_action_released("sprint"):
		is_sprinting = false

func _physics_process(delta):
	# Gravedad
	if not is_on_floor():
		velocity.y -= gravity * delta
	
	# Salto
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity
	
	# Movimiento horizontal
	var input_dir = Vector2()
	if Input.is_action_pressed("move_forward"):
		input_dir.y -= 1
	if Input.is_action_pressed("move_backward"):
		input_dir.y += 1
	if Input.is_action_pressed("move_left"):
		input_dir.x -= 1
	if Input.is_action_pressed("move_right"):
		input_dir.x += 1
	
	if input_dir != Vector2.ZERO:
		input_dir = input_dir.normalized()
		
		# Calcular velocidad con bonificaciones de items
		var current_speed = sprint_speed if is_sprinting else move_speed
		current_speed += get_speed_bonus_from_items()
		
		# Direccion relativa a la cámara
		var direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y))
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
	else:
		velocity.x = move_toward(velocity.x, 0, move_speed * 3 * delta)
		velocity.z = move_toward(velocity.z, 0, move_speed * 3 * delta)
	
	move_and_slide()

func get_speed_bonus_from_items() -> float:
	var bonus: float = 0.0
	for clothing in equipped_clothing:
		if clothing and clothing.has_stat("speed_bonus"):
			bonus += clothing.get_stat("speed_bonus")
	return bonus

func equip_item(item: Item):
	if not item:
		return false
	
	match item.item_type:
		Item.ItemType.WEAPON:
			equip_weapon(item as WeaponItem)
		Item.ItemType.CLOTHING:
			equip_clothing(item as ClothingItem)
		Item.ItemType.ACCESSORY:
			equip_accessory(item as AccessoryItem)
	
	item_equipped.emit(item)
	update_flow_level()
	return true

func equip_weapon(weapon: WeaponItem):
	equipped_weapon = weapon
	print("🔫 Equipped: %s (+%d damage, +%d flow)" % [weapon.item_name, weapon.damage, weapon.flow_bonus])

func equip_clothing(clothing: ClothingItem):
	# Remover ropa del mismo slot si existe
	for i in range(equipped_clothing.size()):
		if equipped_clothing[i] and equipped_clothing[i].clothing_slot == clothing.clothing_slot:
			equipped_clothing[i] = null
			break
	
	equipped_clothing.append(clothing)
	print("👕 Equipped: %s" % clothing.item_name)
	
	# Aplicar efectos visuales de la ropa
	apply_clothing_visual(clothing)

func equip_accessory(accessory: AccessoryItem):
	print("⛓️ Equipped: %s (+%d charisma)" % [accessory.item_name, accessory.charisma_bonus])

func apply_clothing_visual(clothing: ClothingItem):
	# TODO: Cambiar material/textura del personaje según la ropa
	pass

func update_flow_level():
	var total_flow = 0
	
	if equipped_weapon:
		total_flow += equipped_weapon.flow_bonus
	
	for clothing in equipped_clothing:
		if clothing:
			total_flow += clothing.flow_bonus
	
	current_flow_bonus = total_flow
	flow_changed.emit(flow_level + int(current_flow_bonus / 10))

func take_damage(damage: float, source: String = ""):
	health = max(0, health - damage)
	health_changed.emit(health)
	
	print("💥 Took %d damage from %s (Health: %.0f/%.0f)" % [damage, source, health, max_health])
	
	if health <= 0:
		die()

func die():
	print("💀 Player died - respawning...")
	# TODO: Implementar respawn y penalización

func heal(amount: float):
	health = min(max_health, health + amount)
	health_changed.emit(health)

func add_street_cred(amount: int):
	street_cred += amount
	print("📈 Street Cred +%d (Total: %d)" % [amount, street_cred])

func toggle_inventory():
	if inventory_manager:
		inventory_manager.toggle_inventory_ui()

func _on_item_equipped(item: Item):
	equip_item(item)

# Función para debug - mostrar stats actuales
func print_stats():
	print("=== PLAYER STATS ===")
	print("Flow Level: %d (+%.1f from items)" % [flow_level, current_flow_bonus])
	print("Street Cred: %d" % street_cred)
	print("Health: %.0f/%.0f" % [health, max_health])
	if equipped_weapon:
		print("Weapon: %s" % equipped_weapon.item_name)
	print("Clothing items: %d equipped" % equipped_clothing.size())
	print("==================")
'''

# Crear el script base para items
item_script = '''extends Resource
class_name Item

## Clase base para todos los items del juego
## Define propiedades comunes y comportamiento base

enum ItemType {
	WEAPON,
	CLOTHING, 
	ACCESSORY,
	CONSUMABLE
}

enum Rarity {
	COMMON,    # Blanco - Items básicos
	UNCOMMON,  # Verde - Items decentes  
	RARE,      # Azul - Items buenos
	EPIC,      # Morado - Items geniales
	LEGENDARY  # Dorado - Items únicos y divertidos
}

@export var item_name: String = ""
@export var description: String = ""
@export var item_type: ItemType = ItemType.CLOTHING
@export var rarity: Rarity = Rarity.COMMON
@export var icon: Texture2D
@export var mesh: Mesh
@export var flow_bonus: int = 0
@export var price: int = 100

# Stats base que pueden tener todos los items
@export var stats: Dictionary = {}

func _init():
	# Constructor base
	pass

func get_stat(stat_name: String) -> float:
	return stats.get(stat_name, 0.0)

func has_stat(stat_name: String) -> bool:
	return stat_name in stats

func add_stat(stat_name: String, value: float):
	stats[stat_name] = value

func get_rarity_color() -> Color:
	match rarity:
		Rarity.COMMON:
			return Color.WHITE
		Rarity.UNCOMMON:
			return Color.GREEN
		Rarity.RARE:
			return Color.CYAN
		Rarity.EPIC:
			return Color.MAGENTA
		Rarity.LEGENDARY:
			return Color.GOLD
		_:
			return Color.WHITE

func get_flow_description() -> String:
	if flow_bonus > 0:
		return "+%d Flow ✨" % flow_bonus
	return ""

func get_full_description() -> String:
	var full_desc = description
	
	# Agregar stats
	if stats.size() > 0:
		full_desc += "\\n\\nEffects:"
		for stat in stats:
			var value = stats[stat]
			var sign = "+" if value > 0 else ""
			full_desc += "\\n• %s: %s%.1f" % [stat.replace("_", " ").capitalize(), sign, value]
	
	# Agregar flow bonus
	if flow_bonus > 0:
		full_desc += "\\n\\n" + get_flow_description()
	
	return full_desc

# Función llamada cuando el item es equipado
func on_equipped(player: Player):
	print("📦 %s equipped!" % item_name)

# Función llamada cuando el item es desequipado  
func on_unequipped(player: Player):
	print("📦 %s unequipped!" % item_name)
'''

# Crear script específico para armas
weapon_script = '''extends Item
class_name WeaponItem

## Item de arma - extiende la clase base Item
## Armas tienen damage, tipo y efectos especiales

enum WeaponType {
	PISTOL,
	RIFLE,
	MELEE,
	SPECIAL
}

@export var weapon_type: WeaponType = WeaponType.PISTOL
@export var damage: float = 10.0
@export var attack_speed: float = 1.0
@export var range: float = 10.0
@export var ammo_capacity: int = 12
@export var reload_time: float = 2.0

# Efectos especiales únicos del arma
@export var special_effects: Array[String] = []

func _init():
	super._init()
	item_type = ItemType.WEAPON

func get_weapon_description() -> String:
	var desc = "Damage: %.0f\\n" % damage
	desc += "Attack Speed: %.1fx\\n" % attack_speed
	desc += "Range: %.0fm" % range
	
	if weapon_type == WeaponType.PISTOL or weapon_type == WeaponType.RIFLE:
		desc += "\\nAmmo: %d" % ammo_capacity
		desc += "\\nReload: %.1fs" % reload_time
	
	return desc

func on_equipped(player: Player):
	super.on_equipped(player)
	# Aplicar bonificaciones específicas del arma
	if has_stat("intimidation"):
		print("😤 Intimidation increased by %.0f" % get_stat("intimidation"))

# Crear armas de ejemplo
static func create_example_weapons() -> Array[WeaponItem]:
	var weapons: Array[WeaponItem] = []
	
	# Desert Eagle Cromada
	var desert_eagle = WeaponItem.new()
	desert_eagle.item_name = "Desert Eagle Cromada"
	desert_eagle.description = "Una .50 AE cromada que ciega a los enemigos con su brillo. El arma favorita de los gangsters con estilo."
	desert_eagle.weapon_type = WeaponType.PISTOL
	desert_eagle.damage = 45.0
	desert_eagle.attack_speed = 0.7
	desert_eagle.range = 25.0
	desert_eagle.ammo_capacity = 7
	desert_eagle.flow_bonus = 25
	desert_eagle.rarity = Rarity.EPIC
	desert_eagle.price = 2500
	desert_eagle.add_stat("intimidation", 30.0)
	desert_eagle.add_stat("style_points", 50.0)
	desert_eagle.special_effects = ["chrome_blind", "style_kill_bonus"]
	weapons.append(desert_eagle)
	
	# Bate de Baseball Dorado
	var golden_bat = WeaponItem.new()
	golden_bat.item_name = "Bate Louisville Slugger Dorado"
	golden_bat.description = "Bañado en oro de 24 quilates. Perfecto para dar home runs... en las cabezas de tus enemigos."
	golden_bat.weapon_type = WeaponType.MELEE
	golden_bat.damage = 35.0
	golden_bat.attack_speed = 1.2
	golden_bat.range = 2.0
	golden_bat.flow_bonus = 20
	golden_bat.rarity = Rarity.RARE
	golden_bat.price = 1800
	golden_bat.add_stat("knockback", 25.0)
	golden_bat.add_stat("critical_chance", 15.0)
	golden_bat.special_effects = ["golden_shine", "home_run_knockback"]
	weapons.append(golden_bat)
	
	return weapons
'''

# Crear script para ropa
clothing_script = '''extends Item
class_name ClothingItem

## Item de ropa - afecta apariencia y stats del jugador
## La ropa define tu estilo y bonificaciones específicas

enum ClothingSlot {
	HEAD,      # Gorras, lentes, máscaras
	CHEST,     # Camisas, buzos, chaquetas  
	LEGS,      # Pantalones, shorts
	FEET,      # Zapatos, zapatillas
	ACCESSORY  # Relojes, cadenas, anillos
}

@export var clothing_slot: ClothingSlot = ClothingSlot.CHEST
@export var material_override: Material
@export var color_variations: Array[Color] = []

func _init():
	super._init()
	item_type = ItemType.CLOTHING

func on_equipped(player: Player):
	super.on_equipped(player)
	# Aplicar efectos visuales
	apply_visual_effect(player)

func apply_visual_effect(player: Player):
	# TODO: Cambiar apariencia del jugador
	pass

# Crear ropa de ejemplo
static func create_example_clothing() -> Array[ClothingItem]:
	var clothing: Array[ClothingItem] = []
	
	# Buzo Adidas Vintage
	var adidas_hoodie = ClothingItem.new()
	adidas_hoodie.item_name = "Buzo Adidas Vintage"
	adidas_hoodie.description = "Un clásico de los 90s. Las tres rayas dan +20% de éxito en robos. Es ciencia, bro."
	adidas_hoodie.clothing_slot = ClothingSlot.CHEST
	adidas_hoodie.flow_bonus = 15
	adidas_hoodie.rarity = Rarity.UNCOMMON
	adidas_hoodie.price = 800
	adidas_hoodie.add_stat("theft_success", 20.0)
	adidas_hoodie.add_stat("street_respect", 10.0)
	clothing.append(adidas_hoodie)
	
	# Jordan Falsas pero Convincentes
	var fake_jordans = ClothingItem.new()
	fake_jordans.item_name = "Air Jordan Retro (Falsas)"
	fake_jordans.description = "Se ven igual que las originales hasta que llueve. +15% velocidad de escape porque corres como si te persiguieran."
	fake_jordans.clothing_slot = ClothingSlot.FEET
	fake_jordans.flow_bonus = 12
	fake_jordans.rarity = Rarity.COMMON
	fake_jordans.price = 350
	fake_jordans.add_stat("movement_speed", 15.0)
	fake_jordans.add_stat("escape_chance", 20.0)
	fake_jordans.add_stat("detection_resistance", -5.0)  # Menos sigiloso
	clothing.append(fake_jordans)
	
	# Pantalón Cargo Táctico
	var cargo_pants = ClothingItem.new()
	cargo_pants.item_name = "Pantalón Cargo Táctico Negro"
	cargo_pants.description = "42 bolsillos para llevar todo lo que robes. Inventory +3 slots y +10% capacidad de carga."
	cargo_pants.clothing_slot = ClothingSlot.LEGS
	cargo_pants.flow_bonus = 8
	cargo_pants.rarity = Rarity.UNCOMMON
	cargo_pants.price = 600
	cargo_pants.add_stat("inventory_slots", 3.0)
	cargo_pants.add_stat("carry_capacity", 10.0)
	cargo_pants.add_stat("stealth", 5.0)
	clothing.append(cargo_pants)
	
	return clothing
'''

# Guardar todos los scripts
scripts = [
    ("scripts/player/Player.gd", player_script),
    ("scripts/items/Item.gd", item_script),
    ("scripts/items/WeaponItem.gd", weapon_script),
    ("scripts/items/ClothingItem.gd", clothing_script)
]

for script_path, script_content in scripts:
    full_path = os.path.join("gangster-mmo-rpg", script_path)
    with open(full_path, 'w', encoding='utf-8') as f:
        f.write(script_content)
    
    print(f"✅ Script creado: {script_path}")

print(f"\n🎯 {len(scripts)} scripts base creados exitosamente!")
print("\n📋 Scripts incluidos:")
print("• Player.gd - Jugador principal con movimiento 3D")
print("• Item.gd - Clase base para todos los items")
print("• WeaponItem.gd - Armas con stats y efectos")
print("• ClothingItem.gd - Ropa con bonificaciones divertidas")