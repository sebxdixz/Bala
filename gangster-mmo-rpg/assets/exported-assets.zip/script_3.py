# Actualizar el project.godot con los inputs necesarios para los scripts
updated_project_godot = """; Engine configuration file.
; This file contains project settings for Godot 4.

[application]

config/name="Gangster MMO RPG"
config/description="Un MMO RPG 3D con estética chunky pixel art y temática de gangsters"
config/version="0.1.0"
run/main_scene="res://scenes/main_menu/MainMenu.tscn"
config/features=PackedStringArray("4.3")
config/icon="res://assets/art/ui/icon.svg"

[display]

window/size/viewport_width=1920
window/size/viewport_height=1080
window/size/mode=2
window/size/resizable=true

[rendering]

textures/canvas_textures/default_texture_filter=0
2d/use_pixel_snap=true
scaling_3d/mode=1

[input]

move_up={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":87,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
move_down={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":83,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
move_left={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":65,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
move_right={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":68,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
jump={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":32,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
sprint={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":4194325,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
interact={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":69,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}
inventory={
"deadzone": 0.5,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":0,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":73,"physical_keycode":0,"key_label":0,"unicode":0,"echo":false,"script":null)
]
}

[layer_names]

3d_physics/layer_1="Player"
3d_physics/layer_2="Environment" 
3d_physics/layer_3="Items"
3d_physics/layer_4="NPCs"
3d_physics/layer_5="Enemies"
"""

# Guardar el archivo actualizado
project_path = os.path.join("gangster-mmo-rpg", "project.godot")
with open(project_path, 'w', encoding='utf-8') as f:
    f.write(updated_project_godot)

print("✅ project.godot actualizado con inputs y configuraciones")

# Crear un documento de setup e instrucciones
setup_guide = """# 🚀 Guía de Setup - Gangster MMO RPG

## Setup Inicial en Godot 4

### 1. Importar el Proyecto
1. Abre Godot 4.3 o superior
2. Clica "Import" en el Project Manager
3. Navega a la carpeta `gangster-mmo-rpg`
4. Selecciona el archivo `project.godot`
5. Clica "Import & Edit"

### 2. Configuración de Pixel Art
Las configuraciones ya están en el `project.godot`, pero verifica:

**Project Settings > Rendering > Textures:**
- Canvas Textures > Default Texture Filter: `Nearest`

**Project Settings > Rendering > 2D:**
- Use Pixel Snap: `On`

**Project Settings > Rendering > Scaling 3D:**
- Mode: `FSR 1.0`

### 3. Crear la Primera Escena del Jugador

1. **Crear Player.tscn:**
   - Scene > New Scene
   - Add Node > CharacterBody3D (renombrar a "Player")
   - Attach script: `scripts/player/Player.gd`

2. **Estructura del Player:**
   ```
   Player (CharacterBody3D) - Script: Player.gd
   ├── PlayerMesh (MeshInstance3D)
   │   └── Mesh: BoxMesh (temporal)
   │   └── Material: StandardMaterial3D
   ├── CollisionShape3D
   │   └── Shape: BoxShape3D
   ├── CameraPivot (Node3D)
   │   └── Camera3D
   └── InventoryManager (Node) - Script: InventoryManager.gd
   ```

3. **Configurar el BoxMesh:**
   - Size: (1, 2, 1) para simular un personaje
   - Material: Crear un StandardMaterial3D
   - Albedo: Color vibrante (ej: naranja, verde)
   - Flags > Unshaded: On (para look pixel art)

### 4. Crear Escena de Testing

1. **Crear TestLevel.tscn:**
   - Scene > New Scene  
   - Add Node > Node3D (renombrar a "TestLevel")

2. **Agregar un piso:**
   ```
   TestLevel (Node3D)
   ├── Floor (StaticBody3D)
   │   ├── MeshInstance3D
   │   │   └── Mesh: BoxMesh (10x1x10)
   │   └── CollisionShape3D
   │       └── Shape: BoxShape3D (10x1x10)
   └── Player (instancia de Player.tscn)
   ```

### 5. Crear Game Manager Scene

1. **Crear Main.tscn:**
   ```
   Main (Node)
   ├── GameManager (Node) - Script: GameManager.gd
   │   ├── UIManager (Node) 
   │   └── AudioManager (Node)
   └── TestLevel (instancia de TestLevel.tscn)
   ```

## ⌨️ Controles por Defecto

- **WASD**: Movimiento
- **Shift**: Sprint  
- **Space**: Salto
- **Mouse**: Rotar cámara
- **I**: Toggle inventario
- **E**: Interactuar
- **ESC**: Pausa

## 🎯 Testing Inicial

1. Set `Main.tscn` como escena principal (Project Settings > Application > Run > Main Scene)
2. Presiona F5 para correr
3. Deberías poder moverte por el mundo con WASD y mouse
4. Presiona F12 en el juego para abrir la consola y ver los debug prints

## 🔧 Items de Prueba

El sistema viene con 3 items de ejemplo:
- **Buzo Adidas Vintage** (+15 flow, +20% robo)
- **Air Jordan Falsas** (+12 flow, +15% velocidad) 
- **Cadena Dorada Chunky** (+20 flow, +25% intimidación)

Estos se cargan automáticamente en el inventario para testing.

## 🎨 Siguientes Pasos de Arte

1. **Reemplazar BoxMesh del jugador** con un modelo 3D chunky
2. **Crear texturas pixel art** de baja resolución (16x16, 32x32)
3. **Configurar materiales** sin filtrado para mantener píxeles duros
4. **Agregar modelos de items** (buzos, zapatillas, cadenas)

## 🌐 Para MMO (Futuro)

Los scripts están preparados para networking con:
- Sistema de Player ID
- Señales para sincronización
- Separación entre lógica local y del servidor

## 🐛 Debug y Testing

- Usa `player.print_stats()` en la consola para ver stats
- `inventory_manager.print_inventory()` para ver items
- Los prints con emojis aparecen en Output para trackear acciones

---

¡Ahora tienes todo lo necesario para empezar a desarrollar tu MMO RPG gangster chunky! 🔥
"""

# Guardar la guía de setup
setup_path = os.path.join("gangster-mmo-rpg", "docs", "SETUP.md")
os.makedirs(os.path.join("gangster-mmo-rpg", "docs"), exist_ok=True)
with open(setup_path, 'w', encoding='utf-8') as f:
    f.write(setup_guide)

print("✅ Guía de setup creada: docs/SETUP.md")

# Crear un archivo de items de ejemplo adicionales
example_items_script = '''# Items de Ejemplo Adicionales para Gangster MMO RPG

# Agregar estos al InventoryManager o crear como recursos .tres

## ARMAS DIVERTIDAS

### Pistola Nerf Dorada
- Nombre: "Nerf Elite Dorada"
- Descripción: "Modificada ilegalmente para disparar balas de oro. No mata, pero duele el ego."
- Damage: 1 (pero +500% humillación)
- Flow: +30
- Efectos: "Golden Shame" (enemigos se avergüenzan y huyen)

### Bate de Baseball con Clavos
- Nombre: "Louisville Slugger Modificado"
- Descripción: "Perfecto para batear jomruns... en las cabezas de tus enemigos."
- Damage: 45
- Flow: +15
- Efectos: +25% Knockback, hace ruido intimidante

## ROPA LEGENDARIA

### Traje de Baño con Corbata
- Nombre: "Speedo Ejecutivo"
- Descripción: "Para cuando quieres cerrar deals en la playa. +100% confianza, -50% respeto."
- Flow: +5
- Stats: +100% Confidence, -50% Respect, +25% Swimming Speed

### Crocs con Calcetines
- Nombre: "Crocs Comfort Mode"
- Descripción: "El combo más controversial de la moda. Los enemigos no saben si reír o llorar."
- Flow: -10 (pero +50% Comfort)
- Stats: +200% Comfort, -25% Speed, "Confusion Aura" (confunde enemigos)

### Gorro de Lana en Verano
- Nombre: "Beanie Sudoroso"
- Descripción: "Para mostrar que el style no conoce temperaturas. Puro flow urbano."
- Flow: +8
- Stats: +15% Street Cred, -10% Comfort, "Sweat Intimidation"

## ACCESORIOS ABSURDOS

### Reloj de Plástico Dorado
- Nombre: "Rolex de Mercado Libre"
- Descripción: "Se ve caro desde lejos. Muy lejos. Como a 50 metros."
- Flow: +12
- Stats: +20% Fake Wealth, -5% Durability per day

### Lentes de Sol de Noche
- Nombre: "Ray-Ban Nocturnas"
- Descripción: "Para ver cool aunque no veas nada. Perfect for blind swag."
- Flow: +18
- Stats: +35% Coolness, -80% Night Vision, "Blind Style" effect

### Cadena de Perro como Collar
- Nombre: "Cadena Canina Chunky"
- Descripción: "Reciclada de la perrera local. Eco-friendly gangster vibes."
- Flow: +22
- Stats: +30% Intimidation, +15% Animal Friendship, "Rabies Immunity"

## COMBOS DIVERTIDOS

### "El Estafador Elegante"
- Traje + Crocs + Lentes de noche
- Bonus: +50% Scam Success Rate
- Penalty: -25% Credibility

### "Verano Urbano" 
- Beanie + Speedo + Cadena dorada
- Bonus: +100% Meme Potential
- Special: Enemies laugh so hard they can't fight

### "Falso Rico"
- Reloj falso + Jordans falsas + Cadena de perro
- Bonus: +75% Fake Wealth Detection Resistance
- Risk: If caught, -200% Street Cred for 24 hours

---
Estos items están diseñados para ser divertidos y memorables, 
manteniendo el tono irreverente del juego mientras ofrecen 
mecánicas interesantes y efectos únicos.
'''

# Guardar los items de ejemplo
items_path = os.path.join("gangster-mmo-rpg", "docs", "example-items.md")
with open(items_path, 'w', encoding='utf-8') as f:
    f.write(example_items_script)

print("✅ Items de ejemplo creados: docs/example-items.md")

print(f"\n🎉 ¡Proyecto completamente configurado!")
print(f"\n📁 Archivos creados:")
print(f"• 5 Scripts base funcionales")
print(f"• project.godot actualizado con inputs")
print(f"• Guía de setup paso a paso")
print(f"• Items de ejemplo divertidos")
print(f"\n🚀 Próximo paso: Abre Godot 4 e importa el proyecto")
print(f"📖 Lee docs/SETUP.md para instrucciones detalladas")